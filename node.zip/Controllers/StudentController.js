const StudentModel = require("../Models/StudentModel");
const { sendResponse, sendErrorResponse } = require("../Utils/reqResFormat");

const getStudentProfile = async (req, res) => {
  try {
    let studentId = req.query.studentId;
    const user = await StudentModel.findOne({ userId: studentId });
    if (user && user !== undefined) {
      res.status(200).send(sendResponse(user, 0, "success"));
    }
  } catch (error) {
    console.log("error", error);
    res.status(500).send(sendErrorResponse(error, 2, "internal_server_error"));
  }
};

const updateStudentProfile = async (req, res) => {
  try {
    let studentId = req.body.studentId;
    let updateObj = {
      name: req.body.name ? req.body.name : null,
      course: req.body.name ? req.body.course : null,
    };
    let data = await StudentModel.findOne({ studentId: studentId });
    if (data) {
      let updated = await StudentModel.updateOne(
        { studentId: data.studentId },
        updateObj
      );
      if (updated && updated.nModified !== 0) {
        res.status(200).send(sendResponse(updated, 0, "updated"));
      }else{
        res.status(200).send(sendErrorResponse("error", 1, "not_updated"));
      }
    }
  } catch (error) {
    console.log("error", error);
    res.status(500).send(sendErrorResponse(error, 2, "internal_server_error"));
  }
};

module.exports = {
  getStudentProfile,
  updateStudentProfile,
};
