const StudentModel = require("../Models/StudentModel");
const { sendResponse, sendErrorResponse } = require("../Utils/reqResFormat");

const getAllStudents = async (req, res) => {
  try {
    let data = await StudentModel.find();
    if (data) {
      res.status(200).send(sendResponse(data, 0, "success"));
    }
  } catch (error) {
    console.log("error", error);
    res.status(500).send(sendErrorResponse(error, 2, "internal_server_error"));
  }
};

module.exports = {
  getAllStudents,
};
