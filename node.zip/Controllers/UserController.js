const TeacherModel = require("../Models/TeacherModel");
const StudentModel = require("../Models/StudentModel");
const UserModel = require("../Models/UserModel");
const { sendResponse, sendErrorResponse } = require("../Utils/reqResFormat");
const { passwordInBcrypt, matchPassword } = require("../Utils/common");

const createUser = async (req, res) => {
  try {
    console.log("req", req.body);
    let password = await passwordInBcrypt(req.body.password);
    let role = req.body.role.toUpperCase()
    let obj = {
      email: req.body.email,
      password: password,
      role: role,
    };
    let userCreated = await UserModel.create(obj);
    if (userCreated && userCreated !== undefined) {
      console.log("userCreated", userCreated);
      if (role === "STUDENT") {
        let studentCreated = await StudentModel.create({
          userId: userCreated._id,
          studentId: userCreated._id
        });
        if (studentCreated && studentCreated !== undefined) {
          res.status(200).send(sendResponse(userCreated, 0, "created"));
        }
      } else if(role === "TEACHER") {
        let teacherCreated = await TeacherModel.create({
          userId: userCreated._id,
          teacherId: userCreated._id
        });
        if (teacherCreated && teacherCreated !== undefined) {
          res.status(200).send(sendResponse(userCreated, 0, "created"));
        }
      }else{
        res.status(500).send(sendErrorResponse(error, 2, "role_mismatched"));
      }
    } else {
      res
        .status(500)
        .send(sendErrorResponse(error, 2, "validate_err"));
    }
  } catch (error) {
    console.log("error", error);
    res.status(500).send(sendErrorResponse(error, 2, "internal_server_error"));
  }
};

const signInUser = async (req, res) => {
  try {
    let email = req.body.email;
    let password = req.body.password;

    let user = await UserModel.findOne({ email: email });
    console.log("user", user);
    if (user && user !== undefined) {
      let result = await matchPassword(password, user.password);
      if (result) {
        res.status(200).send(sendResponse(user, 0, "login_success"));
      } else {
        res.status(401).send(sendErrorResponse("", 2, "password_not_matched"));
      }
    } else {
      res.status(404).send(sendErrorResponse("", 2, "user_not_found"));
    }
  } catch (error) {
    console.log("error", error);
    res.status(500).send(sendErrorResponse(error, 2, "internal_server_error"));
  }
};

module.exports = {
  createUser,
  signInUser,
};
