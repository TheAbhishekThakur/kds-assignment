const mongoose = require("mongoose");

const studentSchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    required: true,
    ref: "User",
  },
  studentId:{
    type: mongoose.Schema.Types.ObjectId,
    required: true,
  },
  name: {
    type: String,
    required: false,
    trim: true,
    minlength: 1,
    maxlength: 50,
    validate(value) {
      var regName = /^[ a-zA-Z]+(([',. -][ a-zA-Z ])?[ a-zA-Z]*)*$/;
      console.log(regName.test(value));
      if (!regName.test(value)) {
        throw new Error("Kindly Provide with valid Name");
      }
    },
  },
  course: {
    type: String,
    required: false,
    trim: true,
    minlength: 1,
    maxlength: 50,
    validate(value) {
      var regName = /^[ a-zA-Z]+(([',. -][ a-zA-Z ])?[ a-zA-Z]*)*$/;
      console.log(regName.test(value));
      if (!regName.test(value)) {
        throw new Error("Kindly Provide with valid Name");
      }
    },
  },
});

const Students = mongoose.model("Students", studentSchema);
module.exports = Students;