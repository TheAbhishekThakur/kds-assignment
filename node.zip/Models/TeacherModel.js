const mongoose = require("mongoose");

const TeacherSchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    required: true,
    ref: "User",
  },
  teacherId:{
    type: mongoose.Schema.Types.ObjectId,
    required: true,
  },
  name: {
    type: String,
    required: false,
    trim: true,
  },
});

const Teacher = mongoose.model("Teacher", TeacherSchema);
module.exports = Teacher;