const mongoose = require("mongoose");

const userSchema = new mongoose.Schema({
  email: {
    type: String,
    required: true,
    unique: true,
    trim: true,
    lowercase: true,
    validate(value) {
      const emailCheck = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;
      const emailStatus = emailCheck.test(String(value).toLowerCase());
      if (!emailStatus) {
        throw new Error("Email is invalid");
      }
    },
  },
  password: {
    type: String,
    required: true,
    minlength: 7,
    trim: true,
    validate(value) {
      if (value.toLowerCase().includes("password")) {
        throw new Error('Password cannot contain "password"');
      }
    },
  },
  role: {
    type: String,
    required: true,
    trim: true,
    minlength: 1,
    maxlength: 10
  },
  created_at: {
    type: Date,
    default: new Date(),
    required: true,
  },
  updated_at: {
    type: Date,
    default: new Date(),
    required: true,
  },
//   studentId: {
//     type: mongoose.Schema.Types.ObjectId,
//     required: false,
//     ref: "Students",
//   },
//   teacherId: {
//     type: mongoose.Schema.Types.ObjectId,
//     required: false,
//     ref: "Teacher",
//   },
});

const User = mongoose.model("User", userSchema);
module.exports = User;
