const express = require("express");
const router = express.Router();
const StudentController = require("../Controllers/StudentController");

router.get("/get-student-profile", StudentController.getStudentProfile);
router.post("/update-student-profile", StudentController.updateStudentProfile);

module.exports = router;
