const express = require("express");
const router = express.Router();
const TeacherController = require("../Controllers/TeacherController");

router.get("/get-all-students", TeacherController.getAllStudents);

module.exports = router;
