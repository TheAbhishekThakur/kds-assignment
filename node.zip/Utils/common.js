const bcrypt = require("bcrypt");

const passwordInBcrypt = async (password) => {
  // generate salt to hash password
  const salt = await bcrypt.genSalt(10);
  // now we set user password to hashed password
  password = await bcrypt.hash(password, salt);
  return password;
};

const matchPassword = async (reqPassword, dbPassword) => {
  // check user password with hashed password stored in the database
  const validPassword = await bcrypt.compare(reqPassword, dbPassword);
  console.log("validPassword", validPassword);
  if (validPassword) {
    return true;
  } else {
    return false;
  }
};

module.exports = {
    passwordInBcrypt,
    matchPassword
}
