const express = require("express");
const cors = require("cors");
const app = express();
const port = 8000;
const db = require("./Config/db");

// Routes
const userRoute = require("./Routes/UserRoute");
const studentRoute = require("./Routes/StudentRoute");
const teacherRoute = require("./Routes/TeacherRoute");

// Middlewares
app.use(cors());
app.use(express.json());
app.use(express.static("public"));

app.use((req, res, next) => {
  res.header("Access-Control-Allow-Origin", "*");
  res.header(
    "Access-Control-Allow-Headers",
    "Origin, X-Requested-With, Content-Type,Accept,Authorization,access-control-allow-origin"
  );
  if (req.method === "OPTIONS") {
    res.header("Access-Control-Allow-Methods", "PUT,POST,GET,PATCH,DELETE");
    return res.status(200).json({});
  }
  next();
});

// Routes Mapping
app.use("/api/user", userRoute);
app.use("/api/student", studentRoute);
app.use("/api/teacher", teacherRoute);

app.listen(port, () => {
  console.log(`Listening on port ` + port);
});
