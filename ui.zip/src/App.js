import { BrowserRouter, Routes, Route } from "react-router-dom";

// Pages Import
import Login from "./Pages/Login/Login";
import StudentList from "./Pages/Teacher/StudentList/StudentList";
import StudentProfile from "./Pages/Student/StudentProfile/StudentProfile";

function App() {
  return (
    <div className="App">
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Login />} />
          <Route path="/student-list" element={<StudentList />} />
          <Route path="/student-profile/:studentId" element={<StudentProfile />} />
        </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;
