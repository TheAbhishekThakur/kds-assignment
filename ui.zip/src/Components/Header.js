import React from "react";
import { useNavigate } from "react-router-dom";
const Header = () => {
  let navigate = useNavigate();

  const logout = () => {
    localStorage.clear();
    navigate("/");
  };

  return (
    <div>
      <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="container-fluid">
          <a class="navbar-brand" href="#">
            Assignment
          </a>

          <div class="collapse navbar-collapse" id="navbarText">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
              <li class="nav-item">
                
              </li>
            </ul>
            {eval(localStorage.getItem("isLogin")) ? (
              <span
                class="navbar-text"
                style={{ cursor: "pointer" }}
                onClick={logout}
              >
                Logout
              </span>
            ) : null}
          </div>
        </div>
      </nav>
    </div>
  );
};

export default Header;