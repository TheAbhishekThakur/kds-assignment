import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";

const Login = () => {
  let navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  useEffect(() => {
    localStorage.clear();
  }, []);

  const login = () => {
    if (email !== "" && password !== "") {
      let payload = {
        email: email,
        password: password,
      };
      fetch("http://localhost:8000/api/user/login-user", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(payload),
      })
        .then((response) => response.json())
        .then((data) => {
          console.log("Success:", data);
          if (data.responseStatus.statusCode === 0) {
            localStorage.setItem("isLogin", true);
            localStorage.setItem("role", data.responseData.role);
            if (data.responseData.role === "TEACHER") {
              navigate("/student-list");
            } else {
              navigate("/student-profile/" + data.responseData._id);
            }
          }
        })
        .catch((error) => {
          console.error("Error:", error);
        });
    } else {
      alert("Please check usernme or password");
    }
  };

  return (
    <div className="container mt-5">
      <div class="card">
        <div class="card-header">LOGIN</div>
        <div class="card-body">
          <div className="row">
            <div className="col">
              <div class="mb-3">
                <label for="formGroupExampleInput" class="form-label">
                  Email
                </label>
                <input
                  type="email"
                  class="form-control"
                  id="formGroupExampleInput"
                  placeholder="Enter Email"
                  onChange={(e) => setEmail(e.target.value)}
                  value={email}
                />
              </div>
              <div class="mb-3">
                <label for="formGroupExampleInput2" class="form-label">
                  Password
                </label>
                <input
                  type="password"
                  class="form-control"
                  id="formGroupExampleInput2"
                  placeholder="Enter Password"
                  onChange={(e) => setPassword(e.target.value)}
                  value={password}
                />
              </div>
            </div>
          </div>
          <div className="row text-center mt-4">
            <div className="col">
              <button className="btn btn-primary" onClick={login}>
                Login
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Login;
