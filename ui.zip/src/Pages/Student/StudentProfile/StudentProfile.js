import React, { useState, useEffect } from "react";
import { Navigate, useParams } from "react-router-dom";
import Header from "../../../Components/Header";

const UpdateStudentProfile = () => {
  let params = useParams();

  const [studentData, setStudentData] = useState({});

  const inputFieldChanges = (e) => {
    setStudentData({
      ...studentData,
      [e.target.name]: e.target.value,
    });
  };

  const updateStudentProfile = () => {
    let studentId = params.studentId;
    let payload = {
      studentId: studentId,
      name: studentData.name,
      course: studentData.course,
    };
    fetch("http://localhost:8000/api/student/update-student-profile", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(payload),
    })
      .then((response) => response.json())
      .then((data) => {
        console.log("Success:", data);
        if (data.responseStatus.statusCode === 0) {
            alert("Your data has been successfully updated...")
        }else{
            alert("Internal Server Error")
        }
      })
      .catch((error) => {
        console.error("Error:", error);
      });
  };

  useEffect(() => {
    console.log("params", params.studentId);
    let studentId = params.studentId;
    fetch(
      "http://localhost:8000/api/student/get-student-profile?studentId=" +
        studentId,
      {
        method: "GET",
      }
    )
      .then((response) => response.json())
      .then((data) => {
        console.log("Success:", data);
        if (data.responseStatus.statusCode === 0) {
          setStudentData(data.responseData);
        }
      })
      .catch((error) => {
        console.error("Error:", error);
      });
  }, []);
  if (
    eval(localStorage.getItem("isLogin")) &&
    localStorage.getItem("role") === "STUDENT"
  ) {
    return (
      <div>
        <Header />
        <div className="container">
          <div className=" text-center mt-5">
            <h5>My Profile</h5>
          </div>
          <div class="card">
            <div class="card-body">
              <div class="mb-3">
                <label for="formGroupExampleInput" class="form-label">
                  Name
                </label>
                <input
                  type="text"
                  class="form-control"
                  id="formGroupExampleInput"
                  placeholder="Enter Name"
                  defaultValue={studentData.name}
                  name="name"
                  onChange={inputFieldChanges}
                />
              </div>
              <div class="mb-3">
                <label for="formGroupExampleInput2" class="form-label">
                  Course
                </label>
                <input
                  type="text"
                  class="form-control"
                  id="formGroupExampleInput2"
                  placeholder="Enter Course"
                  defaultValue={studentData.course}
                  name="course"
                  onChange={inputFieldChanges}
                />
              </div>
              <div class="mb-3 text-center">
                <button
                  className="btn btn-primary"
                  onClick={updateStudentProfile}
                >
                  Update
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  } else if (
    eval(localStorage.getItem("isLogin")) &&
    localStorage.getItem("role") === "TEACHER"
  ) {
    return (
      <div>
        <Header />
        <div className="container">
          <div className="row text-center mt-5">
            <div className="col">
              <div class="card">
                <div class="card-body">
                  <h5 class="card-title">Student Profile</h5>
                  <p class="card-text">Student Name : {studentData.name}</p>
                  <p class="card-text">Student Course : {studentData.course}</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  } else {
    return <Navigate to="/" />;
  }
};

export default UpdateStudentProfile;
