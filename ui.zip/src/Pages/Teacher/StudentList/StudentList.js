import React, { useState, useEffect } from "react";
import Header from "../../../Components/Header";
import { useNavigate } from "react-router-dom";

const StudentList = () => {
    let navigate = useNavigate();
  const [studentList, setStudentList] = useState([]);

  useEffect(() => {
    fetch("http://localhost:8000/api/teacher/get-all-students", {
      method: "GET",
    })
      .then((response) => response.json())
      .then((data) => {
        console.log("Success:", data);
        if (data.responseStatus.statusCode === 0) {
          setStudentList(data.responseData);
        }
      })
      .catch((error) => {
        console.error("Error:", error);
      });
  }, []);

  const gotoStudentDetails = (studentId) => {
    navigate("/student-profile/" + studentId);
  }
  return (
    <div>
      <Header />
      <div className="container">
        <table class="table mt-5">
          <thead>
            <tr>
              <th scope="col">Sr No.</th>
              <th scope="col">Name</th>
              <th scope="col">Course</th>
            </tr>
          </thead>
          <tbody>
            {studentList.length > 0 ? (
              studentList.map((item, index) => (
                <tr style={{ cursor: "pointer" }} onClick={()=>gotoStudentDetails(item.studentId)}>
                  <td>{index + 1}</td>
                  <td>{item.name}</td>
                  <td>{item.course}</td>
                </tr>
              ))
            ) : (
              <>No Data Found...</>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default StudentList;
